package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.google.firebase.firestore.FirebaseFirestore;

public class ui_back extends AppCompatActivity {
    ActionBar ab;
    TextView tv1;
    Button bt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui);
        this.getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.custom_action_bar);
        View view=getSupportActionBar().getCustomView();
        tv1=findViewById(R.id.usr_1);
        bt1=findViewById(R.id.b1);
        //setting of custom actionbar

        ab=getSupportActionBar(); //object of ACtionbar
        ColorDrawable cd=new ColorDrawable(Color.parseColor("#F07D84"));
        ab.setBackgroundDrawable(cd);
        //color of custom action bar

        Intent intent3=getIntent();
        String nm1=intent3.getStringExtra("name");
        tv1.setText(nm1);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a=new Intent(getApplicationContext(),engineeringcolleges.class);
                startActivity(a);
            }
        });


    }
    }

